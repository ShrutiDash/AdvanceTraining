package fibonacci;

import java.util.Scanner;

public class Q2_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int i,n;
		String sum;
		if(args.length > 0)
		{
			for(String val: args)
				System.out.println(val);
		}
		for(i=0;i<args.length;i++)
		{
			System.out.println(args[i]);
		}
		System.out.println("Enter a Number");
		n=sc.nextInt();
		while(n>1)
		{
			System.out.print(args[1]);
			sum=args[0]+args[1];
			args[0]=args[1];
			args[1]=sum;
			n--;
		}
	}

}
