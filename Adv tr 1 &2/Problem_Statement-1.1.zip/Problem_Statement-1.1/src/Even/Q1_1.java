package Even;

/* Write a program to list all, even numbers less than or equal to the number n.
 * Take the value of n as input from the user */


import java.util.*;
public class Q1_1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n,i;
		System.out.println("enter a number");
		n=sc.nextInt();
		for(i=1;i<=n;i++)
		{
			if(i%2==0)
			{
				System.out.println(i);
			}
		}
	}

}
