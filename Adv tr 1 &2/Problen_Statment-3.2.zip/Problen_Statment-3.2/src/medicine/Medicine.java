package medicine;

public class Medicine
{
	public void displayLabel()
	{
		System.out.println("Company : Apolo Pharmacy");
		System.out.println("Address : Hubli");
		}
	}
class Tablet extends Medicine{
 
public void displayLabel()
{
	System.out.println("store in a cool dry place");
	}
}

class Syrup extends Medicine
{
public void displayLabel()
	{
	System.out.println("Consumption as directed by the Physician");
		}
}

class Ointment extends Medicine
{
	public void displayLabel()
	{
		System.out.println("for external use only");
		}
	}