package Repeated_element;

import java.util.*;
public class Q12 {
	public static void main(String[] args)
    {
		Scanner sc=new Scanner(System.in);
		int n,i,j;
		System.out.println("Enter the size the element");
		n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter the array elements");
		for(i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		for(i=0;i<n;i++)
		{
			for(j=i+1;j<n;j++)
			{
				if(arr[i]==arr[j])
				{
					System.out.println("The first repeated element is "+arr[j]);
					//break;
				}
			}		
		}
    }
}
