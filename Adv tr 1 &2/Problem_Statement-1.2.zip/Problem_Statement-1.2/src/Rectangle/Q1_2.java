package Rectangle;

class Rectangle
{
  private double length;
  private double width;

  public Rectangle()
  {
     length = 0.0;
     width  = 0.0;
  }

     public Rectangle(double l, double w)
  {
     length = l;
     width  = w;
  }

  public void set(double l, double w)
  {
     length = l;
     width  = w;
  }

  
  public double getArea()
  {
     return length * width;
  }

  public double getPerimeter()
  {
     return 2*(length + width);
  }
}


public class Q1_2
{
  public static void main(String[] args)
  {
     // Create a Rectangle object with default values
     Rectangle rectangle1 = new Rectangle();

     System.out.println("Area of Rectangle1 is "
                        + rectangle1.getArea());
     System.out.println("Perimeter of Rectangle1 is "
                        + rectangle1.getPerimeter());

     // Create a Rectangle object with given set of values
     Rectangle rectangle2 = new Rectangle(3.5, 4.2);

     System.out.println("Area of Rectangle2 is "
                        + rectangle2.getArea());
     System.out.println("Perimeter of Rectangle2 is "
                        + rectangle2.getPerimeter());
     
     Rectangle rectangle3 = new Rectangle(4.5, 7.2);

     System.out.println("Area of Rectangle3 is "
                        + rectangle2.getArea());
     System.out.println("Perimeter of Rectangle3 is "
                        + rectangle2.getPerimeter());
     
     Rectangle rectangle4 = new Rectangle(5, 3);

     System.out.println("Area of Rectangle4 is "
                        + rectangle2.getArea());
     System.out.println("Perimeter of Rectangle4 is "
                        + rectangle2.getPerimeter());
     
     Rectangle rectangle5 = new Rectangle(7.5, 5.2);

     System.out.println("Area of Rectangle5 is "
                        + rectangle2.getArea());
     System.out.println("Perimeter of Rectangle5 is "
                        + rectangle2.getPerimeter());
  }
}